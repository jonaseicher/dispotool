<!DOCTYPE html>

<html>
<head>

    <title><?php print $title ?></title>

    <link class="include" rel="stylesheet" type="text/css" href="../src/jquery.jqplot.css" />
    <link rel="stylesheet" type="text/css" href="examples.css" />
    <link type="text/css" rel="stylesheet" href="syntaxhighlighter/styles/shCoreDefault.min.css" />
    <link type="text/css" rel="stylesheet" href="syntaxhighlighter/styles/shThemejqPlot.min.css" />
  
    <!--[if lt IE 9]><script language="javascript" type="text/javascript" src="../src/excanvas.js"></script><![endif]-->
    <script class="include" type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    
<?php include "bodyOpener.php"; ?>
  